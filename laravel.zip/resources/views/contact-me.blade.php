<x-layout>
    <div class="container">
        <form method="GET" class="form" action="mailto:markpwmason@outlook.com" target="_blank">
            <h2>Contact Form</h2>
            <input type="text" class="name" name="name" placeholder="Your name...">

            <input type="text" class="subject" name="subject" placeholder="Subject...">

            <textarea id="body" name="body" placeholder="Message..."></textarea>

            <input id="submitBtn" type="submit" value="Send">

        </form>
    </div>

</x-layout>
