<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mark's Portfolio</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agbalumo&display=swap" rel="stylesheet">
    <?php if(Request::path() == 'admin'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/admin.css']); ?>
    <?php endif; ?>
    <?php if(Request::path() == 'create-post'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/create-post.css']); ?>
    <?php endif; ?>
    <?php if(Request::path() == '/'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/home.css']); ?>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
        <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/swiper.js']); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/weatherHandler.js']); ?>
    <?php endif; ?>
    <?php if(Request::path() == 'contact'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/contact.css']); ?>
    <?php endif; ?>

    <?php if(strpos(Request::path(), 'post/') !== false): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/post.css']); ?>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
        <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/swiper.js']); ?>
    <?php endif; ?>

    <?php if(Request::path() == 'cv'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/cv.css']); ?>
    <?php endif; ?>


</head>

<body>
    <header id="header">
        <div id="headerContainer">
            <h1><a class="headerTitle" href="<?php echo e(route('homePage')); ?>">Mark's Portfolio</a> </h1>
            <h1>
                <a href="<?php echo e(route('cv')); ?>" class="headerLink">CV</a>
            </h1>
            <h1>
                <a href="<?php echo e(route('contactMe')); ?>" class="headerLink">Contact Me</a>
            </h1>
        </div>
    </header>

    <div id="content"><?php echo e($slot); ?></div>

    <footer id="footer">
        <div id="footerContainer">
            <p class="text">Made using Javascript, PHP, Laravel, Blade and MySQL</p>
            <div id="profileContainer">
                <p class="text">Mark Paul William Mason&copy;</p>
                <a id="linkedInLink" href="https://www.linkedin.com/in/mark-mason-701ba01b0/" target="_blank"><img
                        id="linkedInIMG" src="/images/linkedin.webp" alt=""></a>
            </div>

        </div>
    </footer>
</body>


</html>
<?php /**PATH C:\Users\MarkP\Desktop\PortfolioProject\portfolio\resources\views/components/layout.blade.php ENDPATH**/ ?>