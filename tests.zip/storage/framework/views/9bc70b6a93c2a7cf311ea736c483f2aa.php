<footer id="footer">
    <div id="footerContainer">
        <h1>Footer</h1>
    </div>
</footer>
</body>

</html>
<?php /**PATH C:\Users\MarkP\Desktop\PortfolioProject\portfolio\resources\views///components/footer.blade.php ENDPATH**/ ?>