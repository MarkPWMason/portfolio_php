<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php
    $languages = ['CSS', 'HTML', 'JS', 'TS', 'React', 'PHP', 'Laravel'];
    ?>

    <form id="postForm" method="POST" action="<?php echo e(route('publish-post')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input name="title" type="text" placeholder="title">
        <textarea name="description" id="" cols="30" rows="10" placeholder="desc"></textarea>
        <label for="video">Video</label>
        <input name="videos[]" type="file" multiple>
        <input name="link" type="text" placeholder="link to project">
        <textarea name="better" id="" cols="30" rows="10" placeholder="how to make it better"></textarea>
        <textarea name="madeWith" id="" cols="30" rows="10" placeholder="what was it made with"></textarea>

        <label for="screenshots">Screenshots</label>
        <input name="screenshots[]" type="file" multiple>

        
        <select multiple="multiple" name="languages[]" id="languages">
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($language); ?>"><?php echo e($language); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type="submit">
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\MarkP\Desktop\PortfolioProject\portfolio\resources\views/create-post.blade.php ENDPATH**/ ?>