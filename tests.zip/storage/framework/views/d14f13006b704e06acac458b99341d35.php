<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mark's Portfolio</title>
</head>

<body>
    <header id="header">
        <div id="headerContainer">
            <h1>Header</h1>
        </div>
    </header>
<?php /**PATH C:\Users\MarkP\Desktop\PortfolioProject\portfolio\resources\views///components/header.blade.php ENDPATH**/ ?>