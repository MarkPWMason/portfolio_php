<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="homeContainer">
        <h1 id="title"><?php echo e($post->title); ?></h1>
        <p id="postLink">Link to Project: <a target="_blank" href="<?php echo e($post->link); ?>"><?php echo e($post->link); ?></a></p>
        <div id="desc_skillsContainer">
            <?php if(count($post->skills) > 0): ?>
                <div id="skillsContainer">
                    <h2 id="skillsHeader">Skills</h2>
                    <ul id="postSkills">
                        <?php $__currentLoopData = $post->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li id="postSkill"><?php echo e($skill['skill']); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div id="descriptionContainer">
                <h2 id="skillsHeader">Description</h2>
                <p id="postDescription">
                    <?php echo e($post->description); ?>

                </p>
            </div>
        </div>
        <div id="madeWithContainer">
            <div>
                <p class="subTitle">How It Could Be Better</p>
                <p id="better"><?php echo e($post->better); ?></p>
            </div>
            <hr color="000">
            <div>
                <p class="subTitle">What It Was Made With</p>
                <p id="madeWith"><?php echo e($post->madeWith); ?></p>
            </div>

        </div>
        <div id="imageContainer">
            <div class="swiper">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <img id="postImage" src="<?php echo e(route('image', $image->imageUrl)); ?>" />
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="swiper-buttons">
                <span class="swiper-button-prev"></span>
                <span class="swiper-button-next"></span>
            </div>
            <div class="swiper-pagination"></div>
        </div>
        
        <?php if(count($post->videos) > 0): ?>
            <?php $__currentLoopData = $post->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <video id="video" controls>
                        <source src="<?php echo e(route('video', $video->videoFilename)); ?>" type="<?php echo e($video->mimeType); ?>">
                    </video>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\MarkP\Desktop\PortfolioProject\portfolio\resources\views/post.blade.php ENDPATH**/ ?>