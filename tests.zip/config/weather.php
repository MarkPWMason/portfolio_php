<?php

return [
    "weatherAPIKey" => env("WEATHER_API_KEY"),
];
